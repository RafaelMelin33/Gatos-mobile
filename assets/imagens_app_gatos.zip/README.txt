IMAGENS - APP DE GATOS

Arquivos incluídos:
- home_gato.jpg: imagem principal da Home
- persa.jpg, siames.jpg, maine_coon.jpg, bengal.jpg: imagens para a tela Espécies
- galeria_1.jpg até galeria_8.jpg: imagens para a Galeria

As imagens foram preparadas a partir de um mockup visual gerado para este projeto
e podem ser usadas como recursos visuais do trabalho escolar.

Sugestão de pasta no projeto React Native:
assets/
  gatos/
    home_gato.jpg
    persa.jpg
    siames.jpg
    maine_coon.jpg
    bengal.jpg
    galeria_1.jpg
    ...
